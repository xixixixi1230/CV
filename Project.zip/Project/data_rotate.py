from PIL import Image
import os
import cv2 as cv

# tp=Image.open('D:/PycharmProjects/pythonProject7/LPDR/Project/chuan_ (1).jpg')
#
# tp.rotate(20,expand=True).save('D:/PycharmProjects/pythonProject7/LPDR/Project/chuan_ (1)_20.jpg')#旋转20度

dir_path= 'chars3/chars3'

for item in os.listdir(dir_path):
    item_path = os.path.join(dir_path, item) #0、1、2等文件夹的路径
    if os.path.isdir(item_path):
        for subitem in os.listdir(item_path):
            subitem_path = os.path.join(item_path, subitem) #subitem_path是图片的路径
            tp = Image.open(subitem_path)
            tp.rotate(20, expand=True).save(subitem_path)  # 旋转20度